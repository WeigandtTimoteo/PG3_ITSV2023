class Lista:
    def ListaYElemen(self):
        cant = input("Ingrese la lista separando los objetos con una coma (,): ")
        lista = cant.split(",")
        elem = input("Ingrese el elemento a buscar: ")
        for i in range(len(lista)):
            if lista[i] == elem:
                print("El elemento {} se encuentra en la posicion {}".format(elem,i))
                break

a=Lista()
a.ListaYElemen()