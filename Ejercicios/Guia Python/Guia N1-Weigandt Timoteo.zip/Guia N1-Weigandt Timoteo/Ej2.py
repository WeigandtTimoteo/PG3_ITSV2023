class Bisiesto:
    def es_bisiesto():
        anio = input("Ingrese un año: ")
        anio = int(anio)
        if anio % 4 == 0 and anio % 100 != 0 or anio % 400 == 0:
            print(f"El año {anio} es bisiesto")
        else:
            print(f"El año {anio} no es bisiesto")

anio =  Bisiesto
anio.es_bisiesto()