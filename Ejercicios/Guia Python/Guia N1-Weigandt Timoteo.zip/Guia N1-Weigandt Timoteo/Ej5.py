class Capiqua:
    def palindromo(self):
        palabra = input("Ingrese palabra: ")
        palabra = palabra.replace(" ", "")
        palabra = palabra.lower()
        palabra_invertida = palabra[::-1]
        if palabra == palabra_invertida:
            print("Es palindromo")
        else:
            print("No es palindromo")

analisis = Capiqua()
analisis.palindromo()