class Pintame:
    def pintacion(self):
        
        ancho = int(input("Ingrese ancho: "))
        alto = int(input("Ingrese alto: "))
        caracter = input("Ingrese caracter: ")
        for alto in range(alto):
            print(caracter * ancho)

pint=Pintame()
pint.pintacion()