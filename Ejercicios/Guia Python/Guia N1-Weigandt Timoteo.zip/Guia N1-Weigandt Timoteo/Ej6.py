class Vocales():
    def conatar_vocales(self):
        frase=input("Ingrese una frase: ")
        self.vocales = ["a", "e", "i", "o", "u"]
        contador = 0
        for letra in frase:
            if letra in self.vocales:
                contador += 1
        print(f"La frase {frase} tiene {contador} vocales")

analizar = Vocales()
analizar.conatar_vocales()