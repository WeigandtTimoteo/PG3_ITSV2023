class Pintame:
    def pintacion(self):
        
        ancho = int(input("Ingrese ancho: "))
        alto = int(input("Ingrese alto: "))
        caracter = input("Ingrese caracter: ")
        forma = input("Ingrese la forma que desea: T(triangulo) ó R(rectangulo ó cuadrado): ")
        if forma == "R":
            for alto in range(alto):
                print(caracter * ancho)
        else:
            if forma == "T":
                count = 1
                espacio = " " * alto
                while count <= alto:
                    print(espacio + f"{caracter} "* count)
                    count += 1
                    espacio = espacio[:-1]

pint=Pintame()
pint.pintacion()