class Step():
    def is_step_number(num):
        num = input("Ingresa un numero: ")
        num_str = str(num)
        for i in range(len(num_str)-1):
            if abs(int(num_str[i]) - int(num_str[i+1])) != 1:
                print("false")
                return False
        print("true")
        return True
        

numero = Step()
numero.is_step_number()